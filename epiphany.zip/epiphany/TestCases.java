import static org.junit.Assert.*;				
import org.junit.Test;

public class TestCases {

	@Test
	public void wizard() {
		
		Wizard wizard = new Wizard("Harry", 9, 8, 9, 10, 0);
		
		assertEquals(wizard.getName(), "Harry");
		assertEquals(wizard.getBravery(), 9);
		assertEquals(wizard.getHumbleness(), 8);
		assertEquals(wizard.getDiscipline(), 9);
		assertEquals(wizard.getOptimism(), 10);
		assertEquals(wizard.getPreference(), 0);
	}
	
	@Test
	public void sortingPref() {
		SortingHat sortingHat = new SortingHat();
		Wizard wizard = new Wizard("Harry", 9, 8, 9, 10, 0);
		sortingHat.sort(wizard);
		
		assertEquals(wizard.getHouse(), "Gryffindor");
	}
	
	@Test
	public void sortingPrefNot1() {
		SortingHat sortingHat = new SortingHat();
		Wizard wizard = new Wizard("Harry", 9, 6, 9, 10, 0);
		sortingHat.sort(wizard);
		
		assertEquals(wizard.getHouse(), "Slytherin");
	}
	
	@Test
	public void sortingPrefNot2() {
		SortingHat sortingHat = new SortingHat();
		Wizard wizard = new Wizard("Harry", 9, 10, 6, 9, 0);
		sortingHat.sort(wizard);
		
		assertEquals(wizard.getHouse(), "Hufflepuff");
	}
	
	@Test
	public void wand1() {
		Wand wand = new Wand(7, 6, 8);
		
		assertEquals(wand.expelliarmusPower, 7);
		assertEquals(wand.crucioPower, 6);
		assertEquals(wand.stupefyPower, 8);
	}
	
	@Test
	public void wand2() {
		Wand wand = new Wand(7, 6, 8);
		
		assertEquals(wand.attack(), 68);
	}
	
	@Test
	public void duel1() {		
		Wizard wizard1 = new Wizard("Harry", 9, 10, 6, 9, 0);
		Wand wand1 = new Wand(9, 8, 9);
		wizard1.setWand(wand1);
		
		Wizard wizard2 = new Wizard("Malfoy", 9, 10, 6, 9, 0);
		Wand wand2 = new Wand(9, 8, 7);
		wizard2.setWand(wand2);
		
		Duel duel = new Duel();
		Wizard winner = duel.duel(wizard1, wizard2);
		
		assertEquals(winner.getName(), "Harry");
	}
	
	@Test
	public void duel2() {		
		Wizard wizard1 = new Wizard("Harry", 9, 10, 6, 9, 0);
		Wand wand1 = new Wand(9, 8, 9);
		wizard1.setWand(wand1);
		wizard1.setPower();
		
		Wizard wizard2 = new Wizard("Malfoy", 9, 10, 6, 9, 0);
		Wand wand2 = new Wand(9, 8, 7);
		wizard2.setWand(wand2);
		wizard2.setPower();
		
		Duel duel = new Duel();
		Wizard winner = duel.duel(wizard1, wizard2);
		
		assertEquals(wizard1.getPower(), 35);
		assertEquals(wizard2.getPower(), 33);
	}
	
	@Test
	public void duel3() {	
		
		SortingHat sortingHat = new SortingHat();
		Wizard wizard1 = new Wizard("Molly", 9, 10, 10, 8, 0);
		Wand wand1 = new Wand(9, 7, 9);
		
		sortingHat.sort(wizard1);
		assertEquals(wizard1.getHouse(), "Gryffindor");
		wizard1.setWand(wand1);
		wizard1.setPower();
		
		Wizard wizard2 = new Wizard("Bellatrix", 8, 2, 3, 10, 2);
		Wand wand2 = new Wand(8, 10, 7);
		sortingHat.sort(wizard2);
		assertEquals(wizard2.getHouse(), "Slytherin");
		wizard2.setWand(wand2);
		wizard2.setPower();
		
		Duel duel = new Duel();
		Wizard winner = duel.duel(wizard1, wizard2);
		assertEquals(winner.getName(), "Molly");
		assertEquals(wizard1.getPower(), 38);
		assertEquals(wizard2.getPower(), 22);
	}
	
	@Test
	public void duel4() {	
		
		SortingHat sortingHat = new SortingHat();
		Wizard wizard1 = new Wizard("Molly", 9, 10, 10, 8, 0);
		Wand wand1 = new Wand(9, 7, 9);
		
		sortingHat.sort(wizard1);
		assertEquals(wizard1.getHouse(), "Gryffindor");
		wizard1.setWand(wand1);
		wizard1.setPower();
		
		Wizard wizard2 = new Wizard("Bellatrix", 8, 2, 3, 10, 2);
		Wand wand2 = new Wand(8, 10, 7);
		sortingHat.sort(wizard2);
		assertEquals(wizard2.getHouse(), "Slytherin");
		wizard2.setWand(wand2);
		wizard2.setPower();
		
		Wizard wizard3 = new Wizard("Cedric", 0, 1 , 0, 0, 3);
		Wand wand3 = new Wand(7, 7, 4);
		wizard3.setPower();
		wizard3.setWand(wand3);
		sortingHat.sort(wizard3);
		assertEquals(wizard3.getHouse(), "Hufflepuff");
		
		Duel duel = new Duel();
		Wizard winner = duel.duel(wizard1, wizard3);
		assertEquals(winner.getName(), "Molly");
		assertEquals(wizard1.getPower(), 38);
		assertEquals(wizard3.getPower(), 0);
		
		winner=duel.duel(wizard2, wizard3);
		assertEquals(winner.getName(), "Bellatrix");
		assertEquals(wizard2.getPower(), 24);
		assertEquals(wizard3.getPower(), -1);
		assertEquals(wizard3.isWizard(), false);
		
	}

}
