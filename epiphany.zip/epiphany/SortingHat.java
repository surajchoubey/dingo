public class SortingHat {
	
    public void sort(Wizard wizard) {
    	
    	if (wizard.getBravery() > 7 && wizard.getDiscipline() > 7 && wizard.getHumbleness() > 7 && wizard.getOptimism() > 7) {
    		wizard.setHouse(wizard.getPreference());
    		return;
    	}
    	
    	if (wizard.getBravery() > wizard.getDiscipline() && wizard.getBravery() > wizard.getHumbleness() && wizard.getBravery() > wizard.getOptimism()) {
    		wizard.setHouse(0);
    		return;
    	}
    	
    	if (wizard.getDiscipline() > wizard.getBravery() && wizard.getDiscipline() > wizard.getHumbleness() && wizard.getDiscipline() > wizard.getOptimism()) {
    		wizard.setHouse(1);
    		return;
    	}
    	
    	if (wizard.getOptimism() > wizard.getBravery() && wizard.getOptimism() > wizard.getDiscipline() && wizard.getOptimism() > wizard.getHumbleness()) {
    		wizard.setHouse(2);
    		return;
    	}
    	
        wizard.setHouse(3);
    }
}
