public class Wizard implements Student {

    public String name;
    
    private int bravery;

    private int humbleness;
    
    private int discipline;
    
    private int optimism;
    
    private int preference;
    
    private Wand wand;
    
    private String house;
    
    public int power;
    
    public Wizard(String name, int bravery, int humbleness, int discipline, int optimism, int preference) {
        this.name = name;
        this.humbleness = humbleness;
        this.bravery = bravery;
        this.discipline = discipline;
        this.optimism = optimism;
        this.preference = preference;
    }
    
    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public int getBravery() {
        return this.bravery;
    }
    
    @Override
    public int getHumbleness() {
        return this.humbleness;
    }

    @Override
    public int getDiscipline() {
        return this.discipline;
    }

    @Override
    public int getOptimism() {
        return this.optimism;
    }
    
    @Override
    public int getPreference() {
        return this.preference;
    }
    
    @Override
    public String getHouse() {
        return this.house;
    }

    @Override
    public Wand getWand() {
        return this.wand;
    }

    public void setHouse(int houseIndex) {
    	int index = houseIndex;
        this.house = Hogwarts.houses[index];
    }
    
    @Override
    public void setWand(Wand wand) {
        this.wand = wand;
    }

    @Override
    public void setPower() {
        this.power = 
        		this.bravery + 
        		this.discipline + 
        		this.humbleness + 
        		this.optimism;
    }

    @Override
    public int getPower() {
        return this.power;
    }

    @Override
    public boolean isWizard() {
        return this.power >= 0;
    }

}
