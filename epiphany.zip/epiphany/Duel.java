public class Duel {

    public Wizard duel(Wizard wizard1, Wizard wizard2) {
    	
        Wizard winner;
        Wizard loser;
        
        winner = (wizard1.getWand().attack() > wizard2.getWand().attack()) ? wizard1 : wizard2;
        loser = (winner == wizard1) ? wizard2 : wizard1;
        
        winner.getWand().increasePower(winner);
        loser.getWand().decreasePower(loser);
        
        return winner;
    }
}
