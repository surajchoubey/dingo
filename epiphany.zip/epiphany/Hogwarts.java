public interface Hogwarts {

    public static final String[] houses = { 
    		"Gryffindor",
    		"Ravenclaw",
    		"Slytherin",
    		"Hufflepuff"
    	};

    public boolean isWizard();
}