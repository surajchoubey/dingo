public interface AttackInterface {
    public int attack();
}
