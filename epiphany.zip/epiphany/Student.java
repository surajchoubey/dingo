public interface Student extends Hogwarts {
	
    public String getHouse();

    public Wand getWand();

    public void setHouse(int houseIndex);

    public void setWand(Wand wand);

    public void setPower();

    public int getPower();

    public String getName();
    
    public int getBravery();

    public int getHumbleness();

    public int getDiscipline();

    public int getOptimism();

    public int getPreference();

    class Weapon {

        public void increasePower(Wizard winner){
            winner.power += 1;
        }

        public void decreasePower(Wizard loser){
            loser.power -= 1;
        }
    }
}