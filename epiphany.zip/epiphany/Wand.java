public class Wand extends Student.Weapon implements AttackInterface {
	
    public int expelliarmusPower;

    public int crucioPower;
    
    public int stupefyPower;
    
    public Wand(int expelliarmusPower, int crucioPower, int stupefyPower) {
        this.expelliarmusPower = expelliarmusPower;
        this.crucioPower = crucioPower;
        this.stupefyPower = stupefyPower;
    }
    
    @Override
    public int attack() {
        return (expelliarmusPower * stupefyPower) + (crucioPower * 2);
    }
}